using System;

namespace TurtleHeroLaboratorio
{
    class Program
    {
        static void Main(string[] args)
        {
            // Permite exibir caracteres corretamente no console
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // ===== CONSTANTES DO JOGO (valores iniciais) =====
            int energiaInicial = 3; // 3 vidas (cascos), como no GDD do TurtleHero
            int pontosPorAcerto = 100; // pontos base de cada acerto
            int perguntasPorFase = 4; // 4 doces aprisionados por boss
            int totalPerguntas = 12; // 3 fases x 4 perguntas

            // ===== VARIAVEIS DE CONTROLE =====
            int energia = 0; // vidas restantes
            int pontos = 0; // pontuacao acumulada
            int numeroPergunta = 1; // pergunta atual (1 a 12)
            int faseAtual = 1; // fase atual (1 a 3)
            int combo = 0; // acertos seguidos
            int multiplicador = 1; // multiplicador de pontos pelo combo
            int pontosGanhos = 0; // pontos do ultimo acerto
            int docesLibertados = 0; // doces Arcor salvos
            int vidaBoss = 0; // vida restante do boss (4 a 1)
            int i = 0; // contador usado nos desenhos das barras

            bool venceu = false; // true quando derrota os 3 bosses
            bool desistiu = false; // true quando o jogador escolhe sair
            bool respostaValida = false; // validacao da resposta
            bool mostrarTitulo = true; // controla quando exibir o titulo da fase
            bool jogarNovamente = true; // controla o laco de "jogar novamente"

            string opcaoMenu = "";
            string escolhaReplay = "";
            string nomeBoss = "";
            string pergunta = "";
            string alternativas = "";
            string respostaCorreta = "";
            string curiosidade = "";
            string doce = "";
            string resposta = "";
            string barra = "";

            // ===== TELA INICIAL E HISTORIA =====
            Console.WriteLine("=====================================================");
            Console.WriteLine("   TURTLEHERO - A CAIXA DE BOMBOM (Arcor Play)");
            Console.WriteLine("=====================================================");
            Console.WriteLine("Voce dormiu no laboratorio de informatica e, quando");
            Console.WriteLine("acordou, estava TRANCADO dentro do mundo doce da Arcor!");
            Console.WriteLine("Tres bosses capturaram 12 doces Arcor.");
            Console.WriteLine("Voce e a TurtleHero, a Tortuguita guerreira do sabor.");
            Console.WriteLine("Derrote os bosses respondendo as perguntas, liberte os");
            Console.WriteLine("doces e destranque a porta do laboratorio!");
            Console.WriteLine();
            Console.WriteLine("REGRAS:");
            Console.WriteLine("- 3 fases (3 bosses), 4 perguntas por fase.");
            Console.WriteLine("- Acertou: o boss perde vida, voce ganha pontos e liberta 1 doce.");
            Console.WriteLine("- Acertos seguidos formam um COMBO que multiplica os pontos.");
            Console.WriteLine("- Errou: voce perde 1 casco de energia (voce tem " + energiaInicial + ") e o combo zera.");
            Console.WriteLine("- Energia zerou: voce perde. Digite S em uma pergunta para desistir.");
            Console.WriteLine();
            Console.WriteLine("1 - Jogar");
            Console.WriteLine("2 - Sair");

            // Repete ate o jogador digitar uma opcao valida do menu
            while (opcaoMenu != "1" && opcaoMenu != "2")
            {
                Console.Write("Escolha uma opcao: ");
                opcaoMenu = Console.ReadLine();
                if (opcaoMenu == null)
                {
                    opcaoMenu = "";
                }
                opcaoMenu = opcaoMenu.Trim();

                if (opcaoMenu != "1" && opcaoMenu != "2")
                {
                    Console.WriteLine("Opcao invalida! Digite 1 ou 2.");
                }
            }

            if (opcaoMenu == "2")
            {
                jogarNovamente = false;
            }

            // ===== LACO EXTERNO: permite jogar novamente =====
            while (jogarNovamente == true)
            {
                // Reinicia todas as variaveis da partida
                energia = energiaInicial;
                pontos = 0;
                numeroPergunta = 1;
                combo = 0;
                docesLibertados = 0;
                venceu = false;
                desistiu = false;
                mostrarTitulo = true;

                // ===== LACO PRINCIPAL DA PARTIDA =====
                // Continua enquanto tem energia, nao venceu e nao desistiu
                while (energia > 0 && venceu == false && desistiu == false)
                {
                    // Calcula a fase: perguntas 1-4 = fase 1, 5-8 = fase 2, 9-12 = fase 3
                    faseAtual = (numeroPergunta - 1) / perguntasPorFase + 1;

                    // Define o boss da fase
                    if (faseAtual == 1)
                    {
                        nomeBoss = "BIG BIG BIGAO";
                    }
                    else if (faseAtual == 2)
                    {
                        nomeBoss = "7BELOS";
                    }
                    else
                    {
                        nomeBoss = "PLUTONITA";
                    }

                    // Mostra o titulo apenas no inicio de cada fase
                    if (mostrarTitulo == true)
                    {
                        Console.WriteLine();
                        Console.WriteLine("=====================================================");
                        if (faseAtual == 1)
                        {
                            Console.WriteLine("FASE 1 - Fortaleza do BIG BIG BIGAO (aprendizado)");
                            Console.WriteLine("O boss de chiclete rosa prendeu 4 doces. Liberte-os!");
                        }
                        else if (faseAtual == 2)
                        {
                            Console.WriteLine("FASE 2 - Fortaleza do 7BELOS (dificuldade media)");
                            Console.WriteLine("O boss-baralho prendeu mais 4 doces. Cuidado com as cartas!");
                        }
                        else
                        {
                            Console.WriteLine("FASE 3 - Fortaleza da PLUTONITA (batalha final)");
                            Console.WriteLine("O planeta roxo guarda os ultimos 4 doces. Boa sorte!");
                        }
                        Console.WriteLine("=====================================================");
                        mostrarTitulo = false;
                    }

                    // Seleciona pergunta, alternativas, resposta, curiosidade e doce libertado
                    if (numeroPergunta == 1)
                    {
                        pergunta = "O boss Big Big Bigao tem nome inspirado em qual tipo de doce Arcor?";
                        alternativas = "A) Chiclete   B) Caramelo   C) Pirulito   D) Bolacha";
                        respostaCorreta = "A";
                        curiosidade = "Big Big e um chiclete de sabor intenso e duradouro.";
                        doce = "Big Big";
                    }
                    else if (numeroPergunta == 2)
                    {
                        pergunta = "Rocklets sao doces de que tipo?";
                        alternativas = "A) Biscoitos recheados   B) Gelatinas   C) Confeitos coloridos   D) Pirulitos";
                        respostaCorreta = "C";
                        curiosidade = "Rocklets sao confeitos coloridos que tambem viraram tabletes e ovos de Pascoa.";
                        doce = "Rocklets";
                    }
                    else if (numeroPergunta == 3)
                    {
                        pergunta = "Qual ingrediente aparece inteiro e crocante no chocolate Block?";
                        alternativas = "A) Castanha de caju   B) Amendoim   C) Avela   D) Uva passa";
                        respostaCorreta = "B";
                        curiosidade = "Block e conhecido pela espessura, sabor marcante e amendoins inteiros crocantes.";
                        doce = "Block";
                    }
                    else if (numeroPergunta == 4)
                    {
                        pergunta = "A heroina TurtleHero e inspirada em qual doce Arcor?";
                        alternativas = "A) Bon o Bon   B) 7Belo   C) Plutonita   D) Tortuguita";
                        respostaCorreta = "D";
                        curiosidade = "A Tortuguita inspirou a TurtleHero, a guerreira do sabor!";
                        doce = "Poosh";
                    }
                    else if (numeroPergunta == 5)
                    {
                        pergunta = "7Belo e qual tipo de doce?";
                        alternativas = "A) Caramelo mastigavel   B) Chiclete   C) Chocolate   D) Confeito";
                        respostaCorreta = "A";
                        curiosidade = "7Belo e um caramelo mastigavel classico, um dos mais iconicos da Arcor.";
                        doce = "7Belo";
                    }
                    else if (numeroPergunta == 6)
                    {
                        pergunta = "A Arcor e a maior produtora mundial de qual tipo de doce?";
                        alternativas = "A) Chicletes   B) Caramelos duros   C) Biscoitos   D) Sorvetes";
                        respostaCorreta = "B";
                        curiosidade = "A Arcor e a maior produtora mundial de caramelos duros.";
                        doce = "Butter Toffees";
                    }
                    else if (numeroPergunta == 7)
                    {
                        pergunta = "Tortuguita e Triunfo sao marcas de qual empresa?";
                        alternativas = "A) Garoto   B) Arcor   C) Nestle   D) Lacta";
                        respostaCorreta = "B";
                        curiosidade = "A Arcor reune diversas marcas de chocolates, biscoitos e guloseimas.";
                        doce = "Pirulito 7Belo";
                    }
                    else if (numeroPergunta == 8)
                    {
                        pergunta = "Como e a textura dos caramelos Butter Toffees?";
                        alternativas = "A) Crocante   B) Granulada   C) Suave   D) Liquida";
                        respostaCorreta = "C";
                        curiosidade = "Butter Toffees sao caramelos de textura suave.";
                        doce = "Torrone";
                    }
                    else if (numeroPergunta == 9)
                    {
                        pergunta = "Plutonita e um chiclete com identidade de qual tema?";
                        alternativas = "A) Medieval   B) Espacial   C) Aquatico   D) Futebol";
                        respostaCorreta = "B";
                        curiosidade = "Plutonita e um chiclete saborizado de identidade espacial, famoso nos anos 90 e 2000.";
                        doce = "Plutonita";
                    }
                    else if (numeroPergunta == 10)
                    {
                        pergunta = "Em que ano e em qual pais o Bon o Bon foi criado?";
                        alternativas = "A) 1984, Argentina   B) 1995, Brasil   C) 1970, Chile   D) 2001, Espanha";
                        respostaCorreta = "A";
                        curiosidade = "Bon o Bon foi criado em 1984 na Argentina, inspirado no brasileiro Serenata de Amor.";
                        doce = "Bon o Bon";
                    }
                    else if (numeroPergunta == 11)
                    {
                        pergunta = "Em que ano a Tortuguita foi lancada no Brasil?";
                        alternativas = "A) 1985   B) 1990   C) 1995   D) 2005";
                        respostaCorreta = "C";
                        curiosidade = "A Tortuguita foi lancada no Brasil em 1995.";
                        doce = "Tortuguita";
                    }
                    else
                    {
                        pergunta = "O Bon o Bon e vendido em quantos paises?";
                        alternativas = "A) Apenas na Argentina   B) Cerca de 10   C) Cerca de 30   D) Mais de 80";
                        respostaCorreta = "D";
                        curiosidade = "Bon o Bon e vendido em mais de 80 paises.";
                        doce = "Chocolate ao Leite";
                    }

                    // Vida do boss: comeca em 4 e diminui a cada acerto da fase
                    vidaBoss = perguntasPorFase - ((numeroPergunta - 1) % perguntasPorFase);

                    // Desenha a barra de energia (um [C] por casco)
                    barra = "";
                    i = 0;
                    while (i < energia)
                    {
                        barra = barra + "[C]";
                        i = i + 1;
                    }
                    Console.WriteLine();
                    Console.WriteLine("TurtleHero: " + barra + " | Pontos: " + pontos + " | Combo: " + combo);

                    // Desenha a barra de vida do boss (um # por ponto de vida)
                    barra = "";
                    i = 0;
                    while (i < vidaBoss)
                    {
                        barra = barra + "#";
                        i = i + 1;
                    }
                    Console.WriteLine("HP " + nomeBoss + ": " + barra);
                    Console.WriteLine("Pergunta " + numeroPergunta + " de " + totalPerguntas);
                    Console.WriteLine(pergunta);
                    Console.WriteLine(alternativas);

                    // Le a resposta e repete ate ser uma opcao valida
                    respostaValida = false;
                    while (respostaValida == false)
                    {
                        Console.Write("Sua resposta (A, B, C, D ou S para desistir): ");
                        resposta = Console.ReadLine();
                        if (resposta == null)
                        {
                            resposta = "";
                        }
                        resposta = resposta.Trim().ToUpper();

                        if (resposta == "A" || resposta == "B" || resposta == "C"
                            || resposta == "D" || resposta == "S")
                        {
                            respostaValida = true;
                        }
                        else
                        {
                            Console.WriteLine("Opcao invalida! Use A, B, C, D ou S.");
                        }
                    }

                    // Trata a resposta do jogador
                    if (resposta == "S")
                    {
                        desistiu = true;
                    }
                    else if (resposta == respostaCorreta)
                    {
                        // Acerto: combo aumenta e o multiplicador sobe a cada 2 acertos seguidos
                        combo = combo + 1;
                        multiplicador = 1 + (combo - 1) / 2;
                        pontosGanhos = pontosPorAcerto * multiplicador;
                        pontos = pontos + pontosGanhos;
                        docesLibertados = docesLibertados + 1;

                        Console.WriteLine("ACERTOU! O boss levou dano! +" + pontosGanhos + " pontos (combo x" + multiplicador + ")");
                        Console.WriteLine("Doce libertado: " + doce + " -> foi para a caixa de bombom!");
                        Console.WriteLine("Curiosidade: " + curiosidade);

                        // Verifica se o boss foi derrotado (ultima pergunta da fase)
                        if (numeroPergunta % perguntasPorFase == 0)
                        {
                            Console.WriteLine();
                            Console.WriteLine("*** " + nomeBoss + " FOI DERROTADO! 4 doces libertados! ***");

                            if (numeroPergunta == totalPerguntas)
                            {
                                venceu = true;
                            }
                            else
                            {
                                mostrarTitulo = true;
                                Console.Write("Pressione ENTER para ir para a proxima fase...");
                                Console.ReadLine();
                            }
                        }

                        numeroPergunta = numeroPergunta + 1;
                    }
                    else
                    {
                        // Erro: perde 1 de energia e o combo volta a zero
                        energia = energia - 1;
                        combo = 0;
                        Console.WriteLine("ERROU! Voce perdeu 1 casco de energia e o combo zerou.");
                    }
                }

                // ===== TELA FINAL =====
                Console.WriteLine();
                Console.WriteLine("=====================================================");
                if (venceu == true)
                {
                    Console.WriteLine("VITORIA! A caixa de bombom esta completa!");
                    Console.WriteLine("Os 3 bosses foram derrotados e a alegria doce voltou");
                    Console.WriteLine("ao mundo Arcor. A porta do laboratorio foi destrancada!");
                }
                else if (desistiu == true)
                {
                    Console.WriteLine("Voce desistiu e vai esperar alguem abrir a porta...");
                }
                else
                {
                    Console.WriteLine("GAME OVER! Sua energia acabou na fase " + faseAtual + ".");
                    Console.WriteLine("Os bosses venceram desta vez e o laboratorio continua trancado.");
                }
                Console.WriteLine("Doces libertados: " + docesLibertados + " de " + totalPerguntas);
                Console.WriteLine("Pontuacao final: " + pontos);
                Console.WriteLine("=====================================================");

                // ===== PERGUNTA SE QUER JOGAR NOVAMENTE =====
                escolhaReplay = "";
                while (escolhaReplay != "S" && escolhaReplay != "N")
                {
                    Console.Write("Deseja jogar novamente? (S/N): ");
                    escolhaReplay = Console.ReadLine();
                    if (escolhaReplay == null)
                    {
                        escolhaReplay = "";
                    }
                    escolhaReplay = escolhaReplay.Trim().ToUpper();

                    if (escolhaReplay != "S" && escolhaReplay != "N")
                    {
                        Console.WriteLine("Opcao invalida! Digite S ou N.");
                    }
                }

                if (escolhaReplay == "N")
                {
                    jogarNovamente = false;
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Preparando uma nova partida...");
                }
            }

            Console.WriteLine();
            Console.WriteLine("Obrigado por jogar TurtleHero! Ate a proxima.");
        }
    }
}
