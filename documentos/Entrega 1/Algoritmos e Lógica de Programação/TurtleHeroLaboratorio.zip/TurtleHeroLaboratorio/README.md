# TurtleHero - A Caixa de Bombom (C# Console)

PI Arcor Play - Algoritmos e Lógica de Programação - Entrega 1

Equipe: Alessandro Galvão Silva, Murilo Ribeiro Vasconcellos, Valeska Affonso Marques

## Como executar
1. Instale o .NET SDK (8.0 ou superior).
2. Na pasta do projeto, rode: `dotnet run`

## Regras
- 3 fases (bosses Big Big Bigão, 7Belos e Plutonita), 4 perguntas por fase.
- Acertar: o boss perde vida, o jogador ganha pontos (com multiplicador de combo) e liberta 1 doce Arcor.
- Errar: -1 de energia (começa com 3) e o combo zera.
- Fim da partida: vitória (12 acertos), derrota (energia = 0) ou desistência (S).
- Ao terminar, o jogador pode escolher jogar novamente (S/N).
